import java.awt.Graphics;

import javax.swing.JPanel;

public class TargetPrintout extends JPanel{
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		BasicTarget z= new BasicTarget();
		g.fillOval(z.xLocation(), z.yLocation(), z.targetSize(),z.targetSize());
	}
}
