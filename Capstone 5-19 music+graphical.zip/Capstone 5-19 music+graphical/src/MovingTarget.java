import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.Timer;

public class MovingTarget implements Target, ActionListener{
	public int xLocation;
	public int yLocation;
	public Color color;
	public int size;
	public int pointValue;
	Random rand= new Random();
	public MovingTarget() {

			xLocation=400;
			yLocation=400;
			size=50;
			color=Color.BLUE;
			pointValue=200;
		    Timer clock = new Timer(300, this);  // fires every 30 milliseconds 
		    clock.start();
	}
	@Override
	public void setLocation() {
		// TODO Auto-generated method stub
		xLocation=400;
		yLocation=400;
	}

	@Override
	public void draw(Graphics g) {
		
		g.fillOval(xLocation, yLocation, size, size);
		
	}

	@Override
	public int getTargetSize() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public int getPointValue() {
		// TODO Auto-generated method stub
		return pointValue;
	}

	@Override
	public Color getColor() {
		// TODO Auto-generated method stub
		return color;
	}

	@Override
	public int getXLocation() {
		// TODO Auto-generated method stub
		return xLocation;
	}

	@Override
	public int getYLocation() {
		// TODO Auto-generated method stub
		return yLocation;
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if((xLocation<800)&&(xLocation>0)) {
			xLocation-=50;
		}
		else {
			xLocation=750;
		}
		
	}

}
