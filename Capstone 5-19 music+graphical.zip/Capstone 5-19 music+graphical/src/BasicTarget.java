import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class BasicTarget extends JPanel implements Target {
	public int xLocation;
	public int yLocation;
	public Color color;
	public int size;
	public int pointValue;
	Random rand = new Random();
	private Image basicTarget = new ImageIcon("basictarget.png").getImage();

	public BasicTarget() {
		xLocation = 100;
		yLocation = 100;
		size = 100;
		color = Color.BLACK;
		pointValue = 50;
	}

	@Override
	public void setLocation() {
		// TODO Auto-generated method stub
		xLocation = rand.nextInt(800 - size);
		yLocation = rand.nextInt(600 - size);
	}

	@Override
	public void draw(Graphics g) {
		// TODO Auto-generated method stub
		g.drawImage(basicTarget, xLocation, yLocation, this);
	}

	@Override
	public int getTargetSize() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public int getPointValue() {
		// TODO Auto-generated method stub
		return pointValue;
	}

	@Override
	public int getXLocation() {
		// TODO Auto-generated method stub
		return xLocation;
	}

	@Override
	public int getYLocation() {
		// TODO Auto-generated method stub
		return yLocation;
	}

}
