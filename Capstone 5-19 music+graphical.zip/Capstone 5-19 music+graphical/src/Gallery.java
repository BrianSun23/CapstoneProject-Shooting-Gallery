import java.awt.Color;


import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Rectangle;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.Timer;

import java.awt.event.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;
import sun.audio.*;
import java.io.*;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;
import java.awt.event.*;
public class Gallery extends JPanel implements MouseListener, MouseMotionListener, ActionListener {

	private JButton StartButton;
	int x, y;
	boolean motion = false;
	boolean start = true;
	public int pointsGained = 0;
	public int lives = 3;
	BasicTarget target1 = new BasicTarget();
	AdvancedTarget target2 = new AdvancedTarget();
	public int targetsHit = 0;
	private Image background = new ImageIcon("backgroundjava.png").getImage();
	Font customFont;
	private Image splatter = new ImageIcon("pixil-frame-0.png").getImage();
	private Image life = new ImageIcon("heart.png").getImage();
	private Image gameOverScreen = new ImageIcon("gameover.png").getImage();
	Color color = new Color(220, 100, 233);
	private Timer clock = new Timer(1000, this);
	private int seconds;
	private int minutes;
	private boolean timerIsStopped;
	private String strSeconds;
	boolean gameOver = false;

	Font gameOverFont = new Font("Comic Sans MS", Font.BOLD, 30);

	public Gallery() {

		super();
		try {
			// create the font to use. Specify the size!
			customFont = Font.createFont(Font.TRUETYPE_FONT, new File("justicechrome.ttf")).deriveFont(24f);
			GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
			// register the font
			ge.registerFont(customFont);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (FontFormatException e) {
			e.printStackTrace();
		}
		addMouseListener(this);
		addMouseMotionListener(this);
		clock.start();
		strSeconds = "00";
		seconds = 0;
		minutes = 1;
	}

	public void start() {

	}

	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void paintComponent(Graphics g) {

		super.paintComponent(g);
		g.setFont(customFont);
		g.drawImage(background, 0, 0, this);
		if (lives == 3) {
			g.setColor(Color.BLACK);
			g.drawString("Lives:", 525, 20);
			g.drawImage(life, 610, 5, this);
			g.drawImage(life, 642, 5, this);
			g.drawImage(life, 674, 5, this);
		} else if (lives == 2) {
			
			g.drawImage(life, 610, 5, this);
			g.drawImage(life, 642, 5, this);
			g.drawImage(splatter, 674, 5, this);
			
		} else if (lives == 1) {
			g.drawImage(life, 610, 5, this);
			g.drawImage(splatter, 642, 5, this);
			g.drawImage(splatter, 674, 5, this);
			
		} else if (lives == 0) {
			g.drawImage(splatter, 610, 5, this);
			g.drawImage(splatter, 642, 5, this);
			g.drawImage(splatter, 674, 5, this);
			gameOver = true;
		}
		if (gameOver) {
			
			g.setColor(color);
			g.drawImage(gameOverScreen,0,0,this);
			g.drawString("Game Over", 200, 180);
			g.drawString("Targets Hit: " + targetsHit, 200, 200);
			g.drawString("Points Gained: " + pointsGained, 200, 220);
			start = false;
			
		}
		if (motion) {
			g.setColor(Color.BLACK);
			g.drawOval(x - 10, y - 10, 20, 20);
			g.drawLine(x, y - 10, x, y + 10);
			g.drawLine(x - 10, y, x + 10, y);
		}
		if (start) {
			
			g.setColor(Color.BLACK);
			target1.draw(g);
			g.drawString("Points: "+pointsGained , 20, 20);
			if (pointsGained > 500) {

				target2.draw(g);
			}
			
		}
		if (minutes == 0 && seconds < 10) {
			g.setColor(Color.BLACK);

			g.drawString(strSeconds, 230, 20);
			g.drawString("seconds left", 250, 20);
		} else {
			g.setColor(Color.BLACK);

			g.drawString("" + minutes, 260, 20);
			g.drawString(":" + strSeconds, 275, 20);

			if (timerIsStopped) {

				g.drawString("The game", 15, 250);
				g.drawString("has finished.", 15, 275);
				g.drawString("Well done!", 15, 305);
			}
		}
	}

	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		int x = e.getX();
		int y = e.getY();
		int xLocation = target1.getXLocation();
		int yLocation = target1.getYLocation();
		int size = target1.getTargetSize();
		int x2 = e.getX();
		int y2 = e.getY();
		int xLocation2 = target2.getXLocation();
		int yLocation2 = target2.getYLocation();
		int size2 = target2.getTargetSize();

		if (((xLocation < x) && (x < xLocation + size)) && ((yLocation < y) && (y < yLocation + size))) {
			target1.setLocation();
			pointsGained += target1.getPointValue();
			targetsHit += 1;
			repaint();
		} else if (((xLocation2 < x2) && (x2 < xLocation2 + size2))
				&& ((yLocation2 < y2) && (y2 < yLocation2 + size2))) {
			target2.setLocation();
			pointsGained += target2.getPointValue();
			targetsHit += 1;
			repaint();
		}

		else {
			
			lives -= 1;
		}

	}

	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		x = e.getX();
		y = e.getY();
		motion = true;

		repaint();

	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (minutes == 0 && seconds == 1) {
			seconds = 0;
			clock.stop();
			timerIsStopped = true;
			strSeconds = "0";
		} else if (seconds == 01) {
			minutes--;
			seconds--;
			strSeconds = "00";
		} else if (minutes != 0 && seconds == 00) {
			minutes--;
			seconds = 59;
			strSeconds = "59";
		} else {
			seconds--;
			strSeconds = "" + seconds;

			if (seconds < 10 && minutes == 0) {
				strSeconds = "" + seconds;
			}

		}
		if ((minutes == 0) && (seconds == 0)) {
			gameOver = true;
		}

		if (lives == 0) {
			clock.stop();
		}

		repaint();
	}
	public static void playDust() {
		  try {
		   File file = new File( "dust.wav");
		   Clip clip = AudioSystem.getClip();
		   clip.open(AudioSystem.getAudioInputStream(file));
		   clip.start();
		   Thread.sleep(clip.getMicrosecondLength());
		  } catch (Exception e) {
		   System.err.println(e.getMessage());
		  }
		 }
		
}
