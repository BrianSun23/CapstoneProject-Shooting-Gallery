import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

public class ClickOrDie extends JPanel implements Target,ActionListener{
	boolean start=true;
	private int xLocation;
	private int yLocation;
	private int timerCount=6;
	private int size;
	private int pointValue;
	Random rand = new Random();
	Font timerFont= new Font("Arial",Font.BOLD,16);
	private Image codTarget = new ImageIcon("clickordie.png").getImage();
	private Image explosion = new ImageIcon("explosion.png").getImage();
	public ClickOrDie() {
		size=75;
		pointValue=0;
		xLocation = rand.nextInt(725);
		yLocation = rand.nextInt(525);
		Timer clock = new Timer(1000, this);
		clock.start();
	}
	@Override
	public void setLocation() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void draw(Graphics g) {
		// TODO Auto-generated method stub
		g.drawImage(codTarget,xLocation,yLocation,this);
		g.setColor(Color.RED);
		g.setFont(timerFont);
		g.drawString(timerCount+"",xLocation+33 ,yLocation+43 );
	}

	@Override
	public int getTargetSize() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public int getPointValue() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getXLocation() {
		// TODO Auto-generated method stub
		return xLocation;
	}

	@Override
	public int getYLocation() {
		// TODO Auto-generated method stub
		return yLocation;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(start) {
		timerCount-=1;
		}
		if(timerCount==0) {
			start=false;
		}
		repaint();
	}

}
