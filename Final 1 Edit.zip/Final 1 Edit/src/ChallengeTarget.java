import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

public class ChallengeTarget extends JPanel implements Target, ActionListener {
	private int xLocation;
	private int yLocation;
	private boolean grow = true;
	private int size;
	private int pointValue;
	Random rand = new Random();
	private Image challengeTarget = new ImageIcon("challengeTarget.png").getImage();

	public ChallengeTarget() {
		xLocation = 400;
		yLocation = 400;
		size = 5;
		pointValue = 400;
		Timer clock = new Timer(40, this);
		clock.start();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		setLocation();
		grow();
		repaint();
	}

	public void newLocation() {
		xLocation = rand.nextInt(800 - size);
		yLocation = rand.nextInt(600 - size);
	}

	@Override
	public void setLocation() {
		// TODO Auto-generated method stub
		if ((xLocation < 800 - size) && (yLocation < 600 - size)) {
			xLocation += 5;
			yLocation += 5;

		} else if (xLocation >= 800 - size) {
			xLocation = 0;
		} else if (yLocation >= 600 - size) {
			yLocation = 0;
		}
	}

	@Override
	public void draw(Graphics g) {
		// TODO Auto-generated method stub
		g.drawImage(challengeTarget, xLocation, yLocation, size, size, this);
	}

	@Override
	public int getTargetSize() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public int getPointValue() {
		// TODO Auto-generated method stub
		return pointValue;
	}

	@Override
	public int getXLocation() {
		// TODO Auto-generated method stub
		return xLocation;
	}

	@Override
	public int getYLocation() {
		// TODO Auto-generated method stub
		return yLocation;
	}

	public void grow() {

		if (grow) {
			size += 5;
		}
		if (size > 50) {
			grow = false;

		}
		if (grow == false) {
			size -= 5;
		}
		if (size == 0) {

			size = 5;
			grow = true;
		}
	}
}
