import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class AdvancedTarget extends JPanel implements Target {
	private int xLocation;
	private int yLocation;

	private int size;
	private int pointValue;
	Random rand = new Random();
	private Image advancedTarget = new ImageIcon("advancedTarget.png").getImage();

	public AdvancedTarget() {
		xLocation = 400;
		yLocation = 400;
		size = 50;
		pointValue = 100;
	}

	@Override
	public void setLocation() {
		// TODO Auto-generated method stub
		xLocation = rand.nextInt(800 - size);
		yLocation = rand.nextInt(600 - size);
	}

	@Override
	public void draw(Graphics g) {
		// TODO Auto-generated method stub
		g.drawImage(advancedTarget, xLocation, yLocation, this);
	}

	@Override
	public int getTargetSize() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public int getPointValue() {
		// TODO Auto-generated method stub
		return pointValue;
	}

	@Override
	public int getXLocation() {
		// TODO Auto-generated method stub
		return xLocation;
	}

	@Override
	public int getYLocation() {
		// TODO Auto-generated method stub
		return yLocation;
	}

}
