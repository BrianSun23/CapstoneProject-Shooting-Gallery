import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

public class MovingTarget extends JPanel implements Target, ActionListener {
	private int xLocation;
	private int yLocation;

	private int size;
	private int pointValue;
	private Image movingTarget = new ImageIcon("MovingTarget.png").getImage();
	Random rand = new Random();

	public MovingTarget() {
		xLocation = 0;
		yLocation = 300;
		size = 50;
		pointValue = 200;
		Timer clock = new Timer(30, this);
		clock.start();
	}

	@Override
	public void setLocation() {

		if (xLocation < 750) {
			xLocation += 10;
		} else if (xLocation >= 750) {
			xLocation = 0;
		}
	}

	public void setLocationVertical() {

		if (yLocation < 550) {
			yLocation += 10;
		} else if (yLocation >= 550) {
			yLocation = 0;
		}
	}

	public void reset() {
		xLocation = rand.nextInt(800 - size);
		yLocation = rand.nextInt(600 - size);
	}

	@Override
	public void draw(Graphics g) {

		g.drawImage(movingTarget, xLocation, yLocation, this);

	}

	@Override
	public int getTargetSize() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public int getPointValue() {
		// TODO Auto-generated method stub
		return pointValue;
	}

	@Override
	public int getXLocation() {
		// TODO Auto-generated method stub
		return xLocation;
	}

	@Override
	public int getYLocation() {
		// TODO Auto-generated method stub
		return yLocation;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		setLocation();
		repaint();
	}
}
