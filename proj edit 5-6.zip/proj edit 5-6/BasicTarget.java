import java.awt.Color;
import java.util.Random;

public class BasicTarget extends Target {
	public BasicTarget() {
		super(100, Color.YELLOW, 100);
		// TODO Auto-generated constructor stub
	}


}
