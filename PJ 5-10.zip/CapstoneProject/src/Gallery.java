import java.awt.Color;

import java.awt.Graphics;
import java.awt.Rectangle;

import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.event.*;
import java.util.Random;

public class Gallery extends JPanel implements MouseListener,MouseMotionListener,ActionListener{
private JButton StartButton;
int x,y;
boolean motion=false;
boolean start=true;
public int pointsGained=0;
BasicTarget target1=new BasicTarget();


	public Gallery() {
		super();
		addMouseListener(this);
		addMouseMotionListener(this);
	}

	  


	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
	
		
		
	}
	public void paintComponent(Graphics g) {

	super.paintComponent(g);
	if(motion) {
	g.setColor(Color.CYAN);
	g.drawOval(x-10,y-10,20,20);
	g.drawLine (x,y-10,x,y+10);
	g.drawLine (x-10,y,x+10,y);
	}
	if(start) {
	g.setColor(target1.getColor());
	target1.draw(g);
	g.drawString(pointsGained+"", 10, 10);
	}
	}


	
	
	

	
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub 
		
	}

	
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		int x=e.getX();
		int y=e.getY();
		int xLocation=target1.getXLocation();
		int yLocation=target1.getYLocation();
		int size=target1.getTargetSize();
		if(((xLocation<x)&&(x<xLocation+size))&&((yLocation<y)&&(y<yLocation+size))) {
			target1.setLocation();
			pointsGained+=target1.getPointValue();
			repaint();
		}
		
			
	
	}

	
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		  

	  }



	
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		  x = e.getX();
		  y = e.getY();
		  motion=true;
		  
		
			
		  

		  repaint();
	
		    
	}




	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}




	


}
