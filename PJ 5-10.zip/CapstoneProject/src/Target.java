import java.awt.Color;
import java.awt.Graphics;

public interface Target {
public void setLocation();
public void draw(Graphics g);
public int getTargetSize();
public int getPointValue();
public Color getColor();
public int getXLocation();
public int getYLocation();

}
