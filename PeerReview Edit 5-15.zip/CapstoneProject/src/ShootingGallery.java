import java.awt.Color;
import java.awt.event.ActionEvent;

import javax.swing.JButton;
import javax.swing.JFrame;

public class ShootingGallery {
	
	 public static void main(String[] args) {
		 JFrame ShootingGallery= new JFrame("Shooting Gallery");
		 ShootingGallery.setBounds(0, 0, 800, 600);
		 ShootingGallery.getContentPane().setBackground(Color.WHITE);
		 ShootingGallery.setResizable(true); 
		 ShootingGallery.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 Gallery panel = new Gallery();
		 ShootingGallery.add(panel);
		 panel.setBackground(Color.WHITE);
		 ShootingGallery.setVisible(true);
		
	 }
}
