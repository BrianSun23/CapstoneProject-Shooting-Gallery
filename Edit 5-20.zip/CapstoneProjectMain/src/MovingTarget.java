import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

public class MovingTarget extends JPanel implements Target, ActionListener{
	public int xLocation;
	public int yLocation;
	public Color color;
	public int size;
	public int pointValue;
	private Image movingTarget = new ImageIcon("jdowaij.png").getImage();
	Random rand= new Random();
	public MovingTarget() {
			xLocation=50;
			yLocation=50;
			size=50;
			pointValue=200;
		    Timer clock = new Timer(300, this);  // fires every 30 milliseconds 
		    clock.start();
	}
	@Override
	public void setLocation() {
		boolean downward=false;
		if(downward) {
			xLocation+=10;
			
		}
		else if(!downward) {
			xLocation-=10;
		}
		if((yLocation<550)) {
			yLocation+=10;
			
		}
		else if(yLocation>=550) {
			yLocation-=10;
		}
	}
		
	

	@Override
	public void draw(Graphics g) {
		
		g.drawImage(movingTarget,xLocation,yLocation,this);
		
	}

	@Override
	public int getTargetSize() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public int getPointValue() {
		// TODO Auto-generated method stub
		return pointValue;
	}



	@Override
	public int getXLocation() {
		// TODO Auto-generated method stub
		return xLocation;
	}

	@Override
	public int getYLocation() {
		// TODO Auto-generated method stub
		return yLocation;
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
	setLocation();
	repaint();
	}
}
