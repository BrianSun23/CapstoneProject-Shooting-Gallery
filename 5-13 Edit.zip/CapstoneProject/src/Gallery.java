import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.event.*;
import java.util.Random;

public class Gallery extends JPanel implements MouseListener,MouseMotionListener,ActionListener{
private JButton StartButton;
int x,y;
boolean motion=false;
boolean start=true;
public int pointsGained=0;
public int lives=3;
BasicTarget target1=new BasicTarget();
AdvancedTarget target2=new AdvancedTarget();
private Image life = new ImageIcon("heart.png").getImage();



	public Gallery() {
		super();
		addMouseListener(this);
		addMouseMotionListener(this);
	}

	  


	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
	
		
		
	}
	public void paintComponent(Graphics g) {

	super.paintComponent(g);
	if(lives==3) {
	g.drawImage(life,700,500, this );
	g.drawImage(life,730,500, this );
	g.drawImage(life,760,500, this );
	}
	else if(lives==2) {
		g.drawImage(life,700,500, this );
		g.drawImage(life,730,500, this );	
	}
	else if(lives==1) {
		g.drawImage(life,700,500, this );
	}
	else if(lives==0) {
		 Font gameOverFont= new Font("Comic Sans MS", Font.BOLD , 30);
		 g.setFont(gameOverFont);
		g.setColor(Color.RED);
		g.drawString("Luis is Big Gay", 400, 300);
	}
	if(motion) {
	g.setColor(Color.CYAN);
	g.drawOval(x-10,y-10,20,20);
	g.drawLine (x,y-10,x,y+10);
	g.drawLine (x-10,y,x+10,y);
	}
	if(start) {
	g.setColor(target1.getColor());
	target1.draw(g);
	g.drawString(pointsGained+"", 10, 10);
	if(pointsGained>1000) {
		g.setColor(target2.getColor());
		target2.draw(g);
	}
	}
	}


	
	
	

	
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub 
		
	}

	
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		int x=e.getX();
		int y=e.getY();
		int xLocation=target1.getXLocation();
		int yLocation=target1.getYLocation();
		int size=target1.getTargetSize();
		int x2=e.getX();
		int y2=e.getY();
		int xLocation2=target2.getXLocation();
		int yLocation2=target2.getYLocation();
		int size2=target2.getTargetSize();
		if(((xLocation<x)&&(x<xLocation+size))&&((yLocation<y)&&(y<yLocation+size))) {
			target1.setLocation();
			pointsGained+=target1.getPointValue();
			repaint();
		}
		else if(((xLocation2<x2)&&(x2<xLocation2+size2))&&((yLocation2<y2)&&(y2<yLocation2+size2))) {
			target2.setLocation();
			pointsGained+=target2.getPointValue();
			repaint();
		}
		else {
			lives-=1;
		}
		
			
	
	}

	
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		  

	  }



	
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		  x = e.getX();
		  y = e.getY();
		  motion=true;
		  
		
			
		  

		  repaint();
	
		    
	}




	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}




	


}
